export default function ShowDerrickDigger(context) {
    var switchControl = context.evaluateTargetPath('#Page:Hydraulic_Inspection/#Control:FCDerrickDigger/#Value');  
   
    if (switchControl) {
        context.evaluateTargetPath('#Page:Hydraulic_Inspection/#Control:FCAerial').setValue(false);
        // context.getPageProxy().getControl('STHydraulicInspection').getSection('SFStatusCodes').setVisible(true);
        context.getPageProxy().getControl('STHydraulicInspection').getSection('SFControls').setVisible(true);
        context.getPageProxy().getControl('STHydraulicInspection').getSection('SFOutriggers').setVisible(true);
        context.getPageProxy().getControl('STHydraulicInspection').getSection('SFControlValves').setVisible(true);
        context.getPageProxy().getControl('STHydraulicInspection').getSection('SFBooms').setVisible(true);
        // context.getPageProxy().getControl('STHydraulicInspection').getSection('SFComments').setVisible(true);
        // context.getPageProxy().getControl('STHydraulicInspection').getSection('SFShift').setVisible(true);

        context.getPageProxy().getControl('STHydraulicInspection').getSection('SFControlsAerial').setVisible(false);
    } else {
        context.evaluateTargetPath('#Page:Hydraulic_Inspection/#Control:FCAerial').setValue(true);
        // context.getPageProxy().getControl('STHydraulicInspection').getSection('SFStatusCodes').setVisible(false);
        context.getPageProxy().getControl('STHydraulicInspection').getSection('SFControls').setVisible(false);
        context.getPageProxy().getControl('STHydraulicInspection').getSection('SFOutriggers').setVisible(false);
        context.getPageProxy().getControl('STHydraulicInspection').getSection('SFControlValves').setVisible(false);
        context.getPageProxy().getControl('STHydraulicInspection').getSection('SFBooms').setVisible(false);
        // context.getPageProxy().getControl('STHydraulicInspection').getSection('SFComments').setVisible(false);
        // context.getPageProxy().getControl('STHydraulicInspection').getSection('SFShift').setVisible(false);
        
        context.getPageProxy().getControl('STHydraulicInspection').getSection('SFControlsAerial').setVisible(true);
    }
}