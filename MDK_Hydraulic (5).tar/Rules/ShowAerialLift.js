export default function ShowAerialLift(context) {
    var switchControl = context.evaluateTargetPath('#Page:Hydraulic_Inspection/#Control:FCAerial/#Value');  
   
    if (switchControl) {
        context.evaluateTargetPath('#Page:Hydraulic_Inspection/#Control:FCDerrickDigger').setValue(false);
        // context.getPageProxy().getControl('STHydraulicInspection').getSection('SFStatusCodes').setVisible(true);
        context.getPageProxy().getControl('STHydraulicInspection').getSection('SFControlsAerial').setVisible(true);
    } else {
        context.evaluateTargetPath('#Page:Hydraulic_Inspection/#Control:FCDerrickDigger').setValue(true);
        context.getPageProxy().getControl('STHydraulicInspection').getSection('SFControlsAerial').setVisible(false);

        // context.getPageProxy().getControl('STHydraulicInspection').getSection('SFStatusCodes').setVisible(true);
        context.getPageProxy().getControl('STHydraulicInspection').getSection('SFControls').setVisible(true);
        context.getPageProxy().getControl('STHydraulicInspection').getSection('SFOutriggers').setVisible(true);
        context.getPageProxy().getControl('STHydraulicInspection').getSection('SFControlValves').setVisible(true);
        context.getPageProxy().getControl('STHydraulicInspection').getSection('SFBooms').setVisible(true);
    }
}
